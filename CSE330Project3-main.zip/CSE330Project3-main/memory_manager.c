/********************************************************/
// Project module for Group 25
/********************************************************/
/* A kernel module to walk the page tables of a given process and find out how many of the process’ pages */
/* are present in the physical memory (resident set size--RSS), how many are swapped out to disk (swap size--SWAP), */
/* and how many pages are in the process’ working set (working set size--WSS).  */
/********************************************************/
/* ******* Debug Through Console: ********/
/* sudo insmod memory_manager.ko */
/* sudo rmmod memory_manager */
/********************************************************/
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/moduleparam.h>
#include <linux/kthread.h>
#include <linux/sched.h>
#include <linux/time.h>
#include <linux/timekeeping.h>
#include <linux/init.h>
#include <linux/semaphore.h>
#include <linux/sched/signal.h>
#include <linux/list.h>
#include <linux/slab.h>
#include <linux/types.h>
#include <linux/limits.h>
#include <linux/mm.h>
#include <linux/mm_types.h>
#include <linux/hrtimer.h>

/********************************************************/
/* License & Authors*/
/********************************************************/
#define AUTHOR "Almaha, Ariadne, Austin, Bao"
MODULE_AUTHOR(AUTHOR);
MODULE_LICENSE("GPL");
/********************************************************/
/* Process ID */
/********************************************************/
static int p_id = 1000;
module_param(p_id,int,0644);
MODULE_PARM_DESC(uid, "The process id");
/********************************************************/
/* Time related constants */
/********************************************************/
static struct hrtimer kernel_timer;
const long  NanoSecondsPerHour = 3600000000000;
const long  NanoSecondsPerMinute = 60000000000;
static unsigned long NanoSecondsPerSecond = 1000000000; // 10 second timer
/********************************************************/
/* Memory related constants */
/********************************************************/
static int present = 0;
static int proc_wss = 0;
static struct task_struct *task;
/********************************************************/
/* Clear the accessed bit of the pte entry */
/********************************************************/
int ptep_test_and_clear_young(struct vm_area_struct *vma, unsigned long addr, pte_t *ptep)
{
	int ret = 0;
	if (pte_young(*ptep)){
		ret = test_and_clear_bit(_PAGE_BIT_ACCESSED, (unsigned long *) &ptep->pte);
	}
	return ret; 
}

/********************************************************/
/* Check each page table in the hierchy */
/********************************************************/
static int check_pages(struct task_struct * task, unsigned long * address, struct vm_area_struct * vma){

	//Page Table Pointers
	pgd_t *pgd;
	p4d_t *p4d;
	pmd_t *pmd;
	pud_t *pud;
	pte_t *ptep;
	pte_t pte;
	
	//Global Directory
	pgd = pgd_offset(task->mm, address); // get pgd from mm and the page address
	if (pgd_none(*pgd) || pgd_bad(*pgd)){ // check if pgd is bad or does not exist
		return 0;
	}
	
	// 4th Directory
	p4d = p4d_offset(pgd, address); // get p4d from from pgd and the page address
	if (p4d_none(*p4d) || p4d_bad(*p4d)){ // check if p4d is bad or does not exist
		return 0;
	}

	// Upper Directory
	pud = pud_offset(p4d, address); // get pud from from p4d and the page address
	if (pud_none(*pud) || pud_bad(*pud)){ // check if pud is bad or does not exist
		return 0;
	}
	
	//Middle Directory	
	pmd = pmd_offset(pud, address); // get pmd from from pud and the page address
	if (pmd_none(*pmd) || pmd_bad(*pmd)){ // check if pmd is bad or does not exist
		return 0;
	}
	
	//Table
	ptep = pte_offset_map(pmd, address); // get pte from pmd and the page address
	if (!ptep){
		return 0;
	} 
	
	// check if pte does not exist
	pte = *ptep;
	if (ptep_test_and_clear_young(vma, address, ptep) == 1){
		proc_wss++;
	}
	if (pte_present(pte) == 1){
		present++;
	}
	else{
		return 0;
	}
	return 1;
	
}

/********************************************************/
/* Traverse Memory Regions */
/********************************************************/
static int traverse_memory_regions(struct task_struct * task){
	//Check each task
	for_each_process(task){
		//For the task with matching process id
		if(task != NULL && task->pid == p_id){
			struct vm_area_struct * vma = task->mm->mmap;
			//Check each virtual memory area
			for(vma = task->mm->mmap; vma; vma = vma->vm_next){
				//Check each page
				unsigned long page;
       				for(page = vma->vm_start; page<vma->vm_end; page += PAGE_SIZE){
       					//call page walk through, pass the vma, page and the task
					check_pages(task, page, vma);
				}
			}
		}
	}
	return 0;
}

/********************************************************/
/* Reset Callback of HRT  */
/********************************************************/
enum hrtimer_restart no_restart_callback(struct hrtimer *timer) {
	ktime_t currtime , interval;
	currtime = ktime_get();
	interval = ktime_set(0, NanoSecondsPerSecond); hrtimer_forward(timer, currtime , interval);
	hrtimer_forward(timer, currtime, interval);
	traverse_memory_regions(task);
	return HRTIMER_RESTART;
}

/********************************************************/
/* Intialize High resolution timer  */
/********************************************************/
static int timer_init(void){
        //for first two test cases
   	ktime_t ktime = ktime_set(0, NanoSecondsPerSecond);
    	hrtimer_init( &kernel_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL );
    	kernel_timer.function = &no_restart_callback;
    	hrtimer_start( &kernel_timer, ktime, HRTIMER_MODE_REL );
	//for the third case
	/*ktime_t ktime_no_restart = ktime_set( 0, NanoSecondsPerSecond);
    	// Init & Start the hrtimer for NO_RESTART (That is Only WSS)
    	hrtimer_init(&no_restart_hr_timer, CLOCK_MONOTONIC, HRTIMER_MODE_REL);
    	no_restart_hr_timer.function = &no_restart_callback;
    	hrtimer_start(&kernel_timer, ktime_no_restart, HRTIMER_MODE_REL);*/
	return 0;
}

/********************************************************/
/* Module Intializer */
/********************************************************/
static int memory_manager_init(void) {
    // Header print
    printk("CSE 330 Project-3 Module Inserted");
    // Set the time interval
    timer_init();
    return 0;
}

/********************************************************/
/* Module Exit */
/********************************************************/
static void memory_manager_exit(void) {
    // Check the status of timer before we exit.
    if(hrtimer_cancel(&kernel_timer) == 0) {
        printk("The timer was cancelled successfully\n");
    }
    else {
        printk("The timer was still in operation\n");
    }
    // Module Removed.
    printk("CSE330 Project 3 Module Removed\n");
}
/********************************************************/
/* Set Lifecycle of Module */
/********************************************************/
module_init(memory_manager_init); // To be called at module load
module_exit(memory_manager_exit); // To be called at module unload

