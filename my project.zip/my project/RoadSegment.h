#pragma once

class RoadSegment
{
protected:
int length = static_cast<int>(Math::random() * (50 - 10) + 10);
double modifier = 0;
wchar_t roadChar = L'\0';
public:
virtual RoadSegment *generateNeighbor() = 0;
virtual int getLength() = 0;
virtual double getModifier() = 0;
virtual wchar_t getRoadChar() = 0; // Added Method to return Char of the road segment
};
