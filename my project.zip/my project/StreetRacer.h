#pragma once

#include "Racer.h"
#include <string>

class StreetRacer : public Racer
{
public:
StreetRacer()
{
this->speed = Math::random() * (7.0 - 5.5) + 5.5; // Random speed between 7 and 5.5
this->currentProgress = 0;
this->carNumber = racerID++;
}
virtual int getCarNumber() override
{
return carNumber;
}
virtual double getSpeed() override
{
return speed;
}
virtual double getCurrentProgress() override
{
return currentProgress;
}
virtual void resetProgress() override
{
currentProgress = 0;
}
virtual void makeProgress(double modifier) override
{
currentProgress += (speed*modifier) + 0.5;
}
virtual std::wstring toString() override
{
return std::wstring(L"Racer #") + carNumber + std::wstring(L" Street Car - ") + static_cast<int>(currentProgress) + std::wstring(L" units");
}
};
