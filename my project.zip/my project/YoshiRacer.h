#pragma once

#include "Racer.h"
#include <string>

class YoshiRacer : public Racer
{
public:
YoshiRacer()
{
this->speed = Math::random() * (9.0 - 5.0) + 5.0; // Random number between 9 and 5
this->currentProgress = 0;
this->carNumber = racerID++;
}
virtual int getCarNumber() override
{
return carNumber;
}
virtual double getSpeed() override
{
return speed;
}
virtual double getCurrentProgress() override
{
return currentProgress;
}
virtual void resetProgress() override
{
currentProgress = 0;
}
virtual void makeProgress(double modifier) override
{
currentProgress += speed * modifier / 2 + 3;
}
virtual std::wstring toString() override
{
return std::wstring(L"Racer #") + carNumber + std::wstring(L" Yoshi Car - ") + static_cast<int>(currentProgress) + std::wstring(L" units");
}
};
