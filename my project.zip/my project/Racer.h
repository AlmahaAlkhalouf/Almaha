#pragma once

class Racer
{
protected:
int carNumber = 0; // Will take the racerID to set car number
static int racerID = 1; // First racer will be #1
double speed = 0;
double currentProgress = 0;
// Abstract methods for each Racer
public:
virtual int getCarNumber() = 0;
virtual double getSpeed() = 0;
virtual double getCurrentProgress() = 0;
virtual void resetProgress() = 0;
virtual void makeProgress(double modifier) = 0;
};
