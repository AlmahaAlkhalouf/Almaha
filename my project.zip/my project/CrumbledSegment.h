#pragma once

#include "RoadSegment.h"
#include "AsphaltSegment.h"
#include "GravelSegment.h"
#include "DirtSegment.h"
#include <string>

class CrumbledSegment : public RoadSegment
{
public:
CrumbledSegment()
{
this->modifier = Math::random() * (.8 - .6) + .6; // Set randomly for each object between .8 and .6
this->roadChar = L'C';
}
virtual RoadSegment *generateNeighbor() override
{ // Generates random number and returns based on percentages above
double diceRoll = Math::random();
if (diceRoll < .40)
{
return new AsphaltSegment();
}
else if (diceRoll < .65)
{
return new CrumbledSegment();
}
else if (diceRoll < .90)
{
return new GravelSegment();
}
else
{
return new DirtSegment();
}
}
virtual int getLength() override
{
return length;
}
virtual double getModifier() override
{
return modifier;
}
virtual std::wstring toString() override
{
return std::wstring(L"Crumbled - ") + getLength() + std::wstring(L" units");
}
virtual wchar_t getRoadChar() override
{
return roadChar;
}
};
