#pragma once

#include "Racer.h"
#include "RoadSegment.h"
#include "AsphaltSegment.h"
#include "CrumbledSegment.h"
#include "DirtSegment.h"
#include "GravelSegment.h"
#include "SteadyRacer.h"
#include "StreetRacer.h"
#include "RandoRacer.h"
#include "YoshiRacer.h"
#include "ToughRacer.h"
#include <string>
#include <iostream>
#include <stdexcept>

class Race
{
public:
Race()
{
// Initializing variables for race class
int userChoice = 0; // 1 for setting track array size manually, 2 for random size, -1 to quit
int raceSize = 0; // How big track will be for option one
int winnerIndex = -1; // Index if a winner was found, -1 if no winner yet
bool continueProgram = true; // Loop race until -1 is entered
// Declaring arrays to be used
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter has converted this array to a pointer. You will need to call 'delete[]' where appropriate:
//ORIGINAL LINE: Racer[] racersArray;
Racer **racersArray; // Array that holds the 8 racers
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter has converted this array to a pointer. You will need to call 'delete[]' where appropriate:
//ORIGINAL LINE: int[] segmentTracker;
int *segmentTracker; // Parallel array that holds what segment of track racer is on
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter has converted this array to a pointer. You will need to call 'delete[]' where appropriate:
//ORIGINAL LINE: RoadSegment[] userSelectedRaceTrack;
RoadSegment **userSelectedRaceTrack; // Array that holds each road segment, user choice 1
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter has converted this array to a pointer. You will need to call 'delete[]' where appropriate:
//ORIGINAL LINE: RoadSegment[] randomRaceTrack;
RoadSegment **randomRaceTrack; // Array that holds each road segment, user choice 2
Scanner *userInput = new Scanner(System::in);
std::wcout << std::wstring(L"Welcome to the Racer Dirby!") << std::endl;
// Start Race Loop until user selects -1
while (continueProgram)
{
std::wcout << std::wstring(L"Would you like to:") << std::endl;
showOptions(); // Prints menu
// Loops until user selects a 1, 2, or -1
do
{
try
{
userChoice = userInput->nextInt();
if (userChoice != 1 && userChoice != 2 && userChoice != -1)
{
std::wcout << std::wstring(L"Please enter a number from the following choices") << std::endl;
showOptions();
}
}
// Runs if user doesn't enter a number
catch (std::exception &e)
{
std::wcout << std::wstring(L"Please enter a number from the following choices") << std::endl;
showOptions();
}
userInput->nextLine();
} while (userChoice != 1 && userChoice != 2 && userChoice != -1);
// Runs if user selects 1 for manual length of track
if (userChoice == 1)
{
std::wcout << std::wstring(L"Please enter a length for the race.") << std::endl;
// Loops until user selects a number greater than 0
do
{
try
{
raceSize = userInput->nextInt();
if (raceSize < 1)
{
std::wcout << std::wstring(L"Please enter a number greater than 0, for the length of the race") << std::endl;
}
}
// Runs if user doesn't enter a number
catch (std::exception &e)
{
std::wcout << std::wstring(L"Please enter a number greater than 0, for the length of the race") << std::endl;
}
userInput->nextLine();
} while (!(raceSize > 0));
// Creates race track with size user entered
userSelectedRaceTrack = new RoadSegment*[raceSize] ();
// Generates all road segments(elements) for the race track
generateTrackElements(userSelectedRaceTrack);
// Prints out track with length of each segment
OutputTrack(userSelectedRaceTrack);
std::wcout << std::wstring(L"\n") << std::endl;
// Creates racer array
racersArray = new Racer*[8] ();
// Generates all racers randomly into the racersArray
generateRacerElements(racersArray);
// Creates parallel array for tracking racer progress on track
segmentTracker = new int[racersArray->length] ();
// Calls method to simulate the race, and returns the winning car number
winnerIndex = runRace(racersArray, userSelectedRaceTrack, segmentTracker);
// Prints winner
std::wcout << std::wstring(L"Winner of the race: Racer #") << winnerIndex << std::endl;
std::wcout << std::wstring(L"\n\nNEXT RACE\n") << std::endl;
}
// Runs if user selects choice 2, random length of track
if (userChoice == 2)
{
randomRaceTrack = new RoadSegment*[static_cast<int>(Math::random() * ((50 - 10) + 1)) + 10];
// Generates all road segments(elements) for the race track
generateTrackElements(randomRaceTrack);
// Prints out track with length of each segment
OutputTrack(randomRaceTrack);
std::wcout << std::wstring(L"\n") << std::endl;
// Creates racer array
racersArray = new Racer*[8] ();
// Generates all racers randomly into the racersArray
generateRacerElements(racersArray);
// Generates all road segments(elements) for the race track
segmentTracker = new int[racersArray->length] ();
// Calls method to simulate the race, and returns the winning car number
winnerIndex = runRace(racersArray, randomRaceTrack, segmentTracker);
// Prints winner
std::wcout << std::wstring(L"Winner of the race: Racer #") << winnerIndex;
std::wcout << std::wstring(L"\n\nNEXT RACE\n") << std::endl;
}
// Runs if user chooses -1
if (userChoice == -1)
{
std::wcout << std::wstring(L"Program has ended") << std::endl;
// Sets program to end
continueProgram = false;
}
// Resets all variables and arrays for loop case
userChoice = 0;
raceSize = 0;
winnerIndex = -1;
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter converted the original 'null' assignment to a call to 'delete', but you should review memory allocation of all pointer variables in the converted code:
delete[] segmentTracker;
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter converted the original 'null' assignment to a call to 'delete', but you should review memory allocation of all pointer variables in the converted code:
delete[] racersArray;
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter converted the original 'null' assignment to a call to 'delete', but you should review memory allocation of all pointer variables in the converted code:
delete[] userSelectedRaceTrack;
//JAVA TO C++ CONVERTER WARNING: Java to C++ Converter converted the original 'null' assignment to a call to 'delete', but you should review memory allocation of all pointer variables in the converted code:
delete[] randomRaceTrack;
Racer::racerID = 1;
} // End of race loop
userInput->close(); // Closes scanner
} // End of race
private:
void showOptions()
{
std::wcout << std::wstring(L"1 - Determine the length of the race") << std::endl;
std::wcout << std::wstring(L"2 - Run a random race") << std::endl;
std::wcout << std::wstring(L"-1 - Exit") << std::endl;
}
std::wstring OutputTrack(RoadSegment *trackArray[])
{
std::wstring outputReturn = L"Track:\n"; // First adds Track: new line to the return string
outputReturn += (trackArray[0]->getRoadChar() + std::wstring(L":") + trackArray[0]->getLength());
for (int i = 1; i < (sizeof(trackArray) / sizeof(trackArray[0])); i++)
{
outputReturn += (std::wstring(L" - ") + trackArray[i]->getRoadChar() + std::wstring(L":") + trackArray[i]->getLength());
}
outputReturn += (L"\n");
return outputReturn;
}
void generateTrackElements(RoadSegment *trackArray[])
{
double randomNum = Math::random();
// Assigning element one of RoadSegment array randomly
if (randomNum < .25)
{
trackArray[0] = new AsphaltSegment();
}
else if (randomNum < .50)
{
trackArray[0] = new CrumbledSegment();
}
else if (randomNum < .75)
{
trackArray[0] = new DirtSegment();
}
else
{
trackArray[0] = new GravelSegment();
}
for (int i = 1; i < (sizeof(trackArray) / sizeof(trackArray[0])); i++)
{
trackArray[i] = trackArray[i - 1]->generateNeighbor();
}
}
void generateRacerElements(Racer *racerArray[])
{
double randomNum;
for (int i = 0; i < (sizeof(racerArray) / sizeof(racerArray[0])); i++)
{
randomNum = Math::random();
if (randomNum < 1.0 / 6.0)
{
racerArray[i] = new SteadyRacer();
}
else if (randomNum < 1.0 / 6.0 * 2.0)
{
racerArray[i] = new StreetRacer();
}
else if (randomNum < 1.0 / 6.0 * 3.0)
{
racerArray[i] = new DavidRacer();
}
else if (randomNum < (1.0 / 6.0 * 4.0))
{
racerArray[i] = new RandoRacer();
}
else if (randomNum < (1.0 / 6.0 * 5.0))
{
racerArray[i] = new YoshiRacer();
}
else
{
racerArray[i] = new ToughRacer();
}
}
}
public:
virtual void updateOnTrack(Racer *racerArray[], RoadSegment *trackArray[], int segmentTrackerArray[])
{
std::wstring updateOnTrack = L"";
// Runs through each element of racer array, grabs the toString of each element,
// the segmentTracker element and adds one as array starts at 0, and the toString of trackArray
element for (int i = 0; i < (sizeof(racerArray) / sizeof(racerArray[0])); i++)
{
updateOnTrack += racerArray[i] + std::wstring(L" into Segment #") + (1 + segmentTrackerArray[i]) + std::wstring(L" ") + trackArray[segmentTrackerArray[i]] + std::wstring(L" long\n");
}
std::wcout << updateOnTrack << std::endl;
}
private:
void outPutDivider(int loopCount)
{
std::wcout << std::wstring(L"###################################################################### #########") << std::endl;
std::wcout << std::wstring(L"\nUpdate #") << loopCount << std::endl;
std::wcout << std::wstring(L"-------------------------------------------------------------------------------") << std::endl;
}
int runRace(Racer *racerArray[], RoadSegment *trackArray[], int segmentTrackerArray[])
{
bool noWinner = true; // Sets loop condition
int loopCounter = 0; // increases each loop until winner is found
std::wstring trackInfo = std::wstring(L"") + OutputTrack(trackArray);
while (noWinner)
{
loopCounter++;
int checkForWinner = randomWinnerCheck(racerArray, trackArray, segmentTrackerArray);
if (checkForWinner > -1)
{
return checkForWinner;
}
// If no winner was found calls make progress to each racer
for (int i = 0; i < (sizeof(racerArray) / sizeof(racerArray[0])); i++)
{
racerArray[i]->makeProgress(trackArray[segmentTrackerArray[i]]->getModifier());
}
sortRacers(racerArray, segmentTrackerArray);
// Outputs the divider with loop number
outPutDivider(loopCounter);
// Prints track info and, all racers
std::wcout << trackInfo << std::endl;
updateOnTrack(racerArray, trackArray, segmentTrackerArray);
}
return -1;
}
void sortRacers(Racer *racerArray[], int segmentTrackerArray[])
{
// Temp variables to rearrange array
Racer *tempRacer = nullptr;
int tempSegment = 0;
// Uses bubble sort to sort array by segment
for (int i = 0; i < (sizeof(racerArray) / sizeof(racerArray[0])) - 1; i++)
{
for (int j = 0; j < (sizeof(racerArray) / sizeof(racerArray[0])) - i - 1; j++)
{
// Swaps if elements of array if they are in wrong order
if (segmentTrackerArray[j] < segmentTrackerArray[j + 1])
{
tempSegment = segmentTrackerArray[j + 1];
tempRacer = racerArray[j + 1];
segmentTrackerArray[j + 1] = segmentTrackerArray[j];
racerArray[j + 1] = racerArray[j];
segmentTrackerArray[j] = tempSegment;
racerArray[j] = tempRacer;
}
else if (segmentTrackerArray[j] == segmentTrackerArray[j + 1])
{
if (racerArray[j]->currentProgress < racerArray[j + 1]->currentProgress)
{
// Swaps array elements in racer Array and segement tracker to maintain parallelism
tempSegment = segmentTrackerArray[j + 1];
tempRacer = racerArray[j + 1];
segmentTrackerArray[j + 1] = segmentTrackerArray[j];
racerArray[j + 1] = racerArray[j];
segmentTrackerArray[j] = tempSegment;
racerArray[j] = tempRacer;
}
}
}
}
}
int randomWinnerCheck(Racer *racerArray[], RoadSegment *trackArray[], int segmentTrackerArray[])
{
// Initializing variables
int numberOfWinners = 0;
int randomGen;
// Loops through all racers
for (int i = 0; i < (sizeof(racerArray) / sizeof(racerArray[0])); i++)
{
if (racerArray[i]->getCurrentProgress() >= trackArray[segmentTrackerArray[i]]->length)
{
// If over then the racers progress is reset to 0 and the segment tracker is increased by one
racerArray[i]->resetProgress();
segmentTrackerArray[i]++;
}
// Checks to see if there are any winners and adds to how many there are
if (segmentTrackerArray[i] >= (sizeof(trackArray) / sizeof(trackArray[0])))
{
numberOfWinners++;
}
}
if (numberOfWinners > 0)
{
// Generates a random number between 0 and (the number of winners - 1) to get the index number
of the winner->randomGen = static_cast<int>(Math::random() * numberOfWinners);
// Sorts the racers and returns the car number of the randomly generated car winner
sortRacers(racerArray, segmentTrackerArray);
return racerArray[randomGen]->carNumber;
}
return -1; // Returns -1 if no winner is found
}
};
