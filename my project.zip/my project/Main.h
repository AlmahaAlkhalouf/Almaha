#pragma once

#include "Race.h"
#include <string>

class Main
{
//JAVA TO C++ CONVERTER TODO TASK: Most Java annotations will not have direct C++ equivalents:
//ORIGINAL LINE: @SuppressWarnings("unused") public static void main(String[] args)
static void main(std::wstring args[])
{
// Runs race
Race *racing = new Race();
}
};
