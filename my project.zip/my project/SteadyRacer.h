#pragma once

#include "Racer.h"
#include <string>

class SteadyRacer : public Racer
{
public:
SteadyRacer()
{
this->speed = Math::random() * (4.0 - 3.0) + 3.0; // Random number between 4 and 3
this->currentProgress = 0;
this->carNumber = racerID++;
}
virtual int getCarNumber() override
{
return carNumber;
}
virtual double getSpeed() override
{
return speed;
}
virtual double getCurrentProgress() override
{
return currentProgress;
}
virtual void resetProgress() override
{
currentProgress = 0;
}
virtual void makeProgress(double modifier) override
{
currentProgress += speed;
}
virtual std::wstring toString() override
{
return std::wstring(L"Racer #") + carNumber + std::wstring(L" Steady Car - ") + static_cast<int>(currentProgress) + std::wstring(L" units");
}
};
