#pragma once

#include "Racer.h"
#include <string>

class ToughRacer : public Racer
{
public:
ToughRacer()
{
this->speed = Math::random() * (3.0 - 2.0) + 2.0; // Random speed between 3 and 2
this->currentProgress = 0;
this->carNumber = racerID++;
}
virtual int getCarNumber() override
{
return carNumber;
}
virtual double getSpeed() override
{
return speed;
}
virtual double getCurrentProgress() override
{
return currentProgress;
}
virtual void resetProgress() override
{
currentProgress = 0;
}
virtual void makeProgress(double modifier) override
{
double bonusSpeed;
bonusSpeed = 5 * (1.0 - modifier);
currentProgress += speed + bonusSpeed;
}
virtual std::wstring toString() override
{
return std::wstring(L"Racer #") + carNumber + std::wstring(L" Tough Car - ") + static_cast<int>(currentProgress) + std::wstring(L" units");
}
};
