#pragma once

#include "RoadSegment.h"
#include "GravelSegment.h"
#include "CrumbledSegment.h"
#include "AsphaltSegment.h"
#include <string>

class DirtSegment : public RoadSegment
{
public:
DirtSegment()
{
this->modifier = Math::random() *.3; // Set randomly for each object between 0 and .3
this->roadChar = L'D';
}
virtual RoadSegment *generateNeighbor() override
{
// Generates random number and returns based on percentages above
double diceRoll = Math::random();
if (diceRoll < .60)
{
return new DirtSegment();
}
else if (diceRoll < .90)
{
return new GravelSegment();
}
else if (diceRoll < .95)
{
return new CrumbledSegment();
}
else
{
return new AsphaltSegment();
}
}
virtual int getLength() override
{
return length;
}
virtual double getModfier() override
{
return modifier;
}
virtual std::wstring toString() override
{
return std::wstring(L"Dirt - ") + getLength() + std::wstring(L" units");
}
virtual wchar_t getRoadChar() override
{
return roadChar;
}
};


