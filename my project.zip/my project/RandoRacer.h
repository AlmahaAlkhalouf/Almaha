#pragma once

#include "Racer.h"
#include <string>

class RandoRacer : public Racer
{
public:
RandoRacer()
{
this->speed = 0;
this->currentProgress = 0; // Randomly makes progress from 0 to 28 per makeProgress method
this->carNumber = racerID++;
}
virtual int getCarNumber() override
{
return carNumber;
}
virtual double getSpeed() override
{
return speed;
}
virtual double getCurrentProgress() override
{
return currentProgress;
}
virtual void resetProgress() override
{
currentProgress = 0;
}
virtual void makeProgress(double modifier) override
{
currentProgress += Math::random() * 28.0;
}
virtual std::wstring toString() override
{
return std::wstring(L"Racer #") + carNumber + std::wstring(L" Rando Car - ") + static_cast<int>(currentProgress) + std::wstring(L" units");
}
};
