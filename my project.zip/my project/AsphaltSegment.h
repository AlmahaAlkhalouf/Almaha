#pragma once

#include "RoadSegment.h"
#include "CrumbledSegment.h"
#include "GravelSegment.h"
#include "DirtSegment.h"
#include <string>

class AsphaltSegment : public RoadSegment
{
public:
AsphaltSegment()
{
his->modifier = 1.0;
his->roadChar = L'A';
}
virtual RoadSegment *generateNeighbor() override
{
double diceRoll = Math::random();
if (diceRoll < .6)
{
return new AsphaltSegment();
}
else if (diceRoll < .85)
{
return new CrumbledSegment();
}
else if (diceRoll < .95)
{
return new GravelSegment();
}
else
{
return new DirtSegment();
}
}
virtual int getLength() override
{
return length;
}
virtual double getModifier() override
{
return modifier;
}
virtual std::wstring toString() override
{
return std::wstring(L"Asphalt - ") + getLength() + std::wstring(L" units");
}
virtual wchar_t getRoadChar() override
{
return roadChar;
}
};


